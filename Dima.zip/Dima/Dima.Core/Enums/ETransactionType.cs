namespace Dima.Core.Enums;

public enum ETransactionType
{
    Deposit = 1,
    Withdraw = 2,
}